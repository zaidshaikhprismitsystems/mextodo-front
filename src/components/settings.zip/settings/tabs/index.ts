import Billing from './billing';
// import ApiKeys from './api-keys';
import Password from './password';
// import Referrals from './referrals';
// import Statements from './statements';
import Preferences from './preferences';
import Seo from './seo';
// import Notifications from './notifications';
import DeleteAccount from './delete-account';
// import SocialAccounts from './social-accounts';
import EmailSettings from './email-settings';
import Envia from './envia';
// import ConnectedAccounts from './connected-accounts';
// import TwoStepVerification from './two-step-verification';

const Tabs = {
  Billing,
  Password,
  Seo,
  // Referrals,
  Preferences,
  // Notifications,
  DeleteAccount,
  EmailSettings,
  Envia
  // TwoStepVerification
};

export default Tabs;