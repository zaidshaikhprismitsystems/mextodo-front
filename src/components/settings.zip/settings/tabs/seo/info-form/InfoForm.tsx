import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Grid from '@mui/material/Grid2';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import TextField from '@mui/material/TextField';
import KeyboardArrowDown from '@mui/icons-material/KeyboardArrowDown';
import * as Yup from 'yup';
import { useFormik } from 'formik'; // CUSTOM COMPONENTS

import { H6, Paragraph } from '../../../../../components/typography';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppSelector } from '../../../../../services/store/hooks/hooks';
import { RootState } from '../../../../../services/store/store';
import ApiService from '../../../../../services/apiServices/apiService';
import LoadingButton from '@mui/lab/LoadingButton';
import Toast from '../../../../../utils/toast';
import { FlexBox } from '../../../../flexbox';
import { TextBox } from '../../../../textbox';
import Checkbox from '@mui/material/Checkbox';
import { Typography } from '@mui/material';
export default function InfoForm() {

  const navigate = useNavigate();
  
  const [userDetails, setUserData] = useState<any>(false);
  const [isSubmitting, setIsSubmitting] = useState<any>(false);
  const [isLoading, setIsLoading] = useState(true);
  
  const { t } = useTranslation();

  const userData: any = useAppSelector((state: RootState) => state.user);

  useEffect(() => {
    getUserData();
  }, []);

  const getUserData = async () => {
    try {
      let data = await ApiService.getUserData();
      setUserData(data.data.data.userData);
    } catch (e) {
      console.log(e);
    } finally {
      setIsLoading(false);
    }
  };

  const validationSchema = Yup.object({
    firstName: Yup.string().min(3, 'Must be greater then 3 characters').required('First Name is Required!'),
    lastName: Yup.string().required('Last Name is Required!'),
    key: Yup.string().required('key is Required!'),
    email: Yup.string().email('Invalid email address').required('Email is Required!'),
    currency: Yup.string().required('Currency is Required!'),
    language: Yup.string().required('Language is Required!')
  });

  const initialValues = {
    firstName: userDetails.firstName,
    lastName: userDetails.lastName,
    key: userDetails.key,
    email: userDetails.email,
    currency: userDetails.currency,
    language: userDetails.language,
  };
  
  const {
    values,
    errors,
    handleSubmit,
    handleChange,
    handleBlur,
    touched
  } = useFormik({
    initialValues,
    validationSchema,
    enableReinitialize: true,
    onSubmit: async (values: any) => {
      try {
        setIsSubmitting(true);
        let saveProfileData = await ApiService.saveProfile({id: userData.userDetails.id, firstName: values.firstName, lastName: values.lastName, currency: values.currency, language: values.language });
        Toast.showSuccessMessage("Profile Updated Successfully");
      } catch (error: any) {
        console.log('error: ', error);
        Toast.showErrorMessage(error.response.data.message);
        setIsSubmitting(false);
      }finally{
        setIsSubmitting(false);
      }
    }
  });

  return <Card>
      <H6 fontSize={14} px={1} m={2}>
      Email Settings
      </H6>

      <Divider />

      {
        isLoading ? "Loading..." :
        <form onSubmit={handleSubmit}>
          <Box margin={3}>
            <Grid container spacing={3}>
            <Grid size={{
                sm: 6,
                xs: 12
              }}>
                <TextBox type={"text"} fullWidth name=" " placeholder={"Title"} onBlur={handleBlur} onChange={handleChange} value={values.title} helperText={touched.title && errors.title ? String(errors.title) : ""} error={Boolean(touched.title && errors.title)}
               
              />
               <Typography variant="caption"  >Custom title for home page (landing page)</Typography>
              </Grid>
              <Grid size={{
                sm: 6,
                xs: 12
              }}>
                <TextBox type={"meta"} fullWidth name=" " placeholder={"Meta keywords"} onBlur={handleBlur} onChange={handleChange} value={values.meta} helperText={touched.meta && errors.meta ? String(errors.meta) : ""} error={Boolean(touched.meta && errors.meta)}
               
               />
                <Typography variant="caption"  >Custom meta keywords for home page (landing page).</Typography>
              </Grid>

              <Grid size={{
                sm: 6,
                xs: 12
              }}>
                <TextBox type={"text"} fullWidth name="key" placeholder={"key"} onBlur={handleBlur} onChange={handleChange} value={values.key} helperText={touched.key && errors.key ? String(errors.key) : ""} error={Boolean(touched.key && errors.key)}
                />
              </Grid>
             
              <Grid size={12}>
                <FlexBox gap={2}>
                
                <Button variant="outlined" sx={{minWidth:'120px' }}>
                  Reset
                </Button>
                <LoadingButton loading={isSubmitting} type="submit" variant="contained"  sx={{minWidth:'120px' }}>
                  Save
                </LoadingButton>
                </FlexBox>

              </Grid>
            </Grid>
          </Box>
        </form>
      }
    </Card>;
}