import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Grid from '@mui/material/Grid2';
import Stack from '@mui/material/Stack';
import Button from '@mui/material/Button';
import Switch from '@mui/material/Switch';
import Divider from '@mui/material/Divider';
import Checkbox from '@mui/material/Checkbox';
import TextField from '@mui/material/TextField'; // MUI ICON COMPONENT

import KeyboardArrowDown from '@mui/icons-material/KeyboardArrowDown'; // CUSTOM COMPONENTS

import FlexBetween from '../../../../components/flexbox/FlexBetween';
import { H6, Paragraph, Small } from '../../../../components/typography'; // CUSTOM DUMMY DATA SET

import { PREFERENCES } from './data';
import { FlexBox } from '../../../flexbox';
import IconWrapper from '../../../icon-wrapper'
import * as Yup from 'yup';
import { useFormik } from "formik";
import { TextBox } from "../../../textbox";
import { useTranslation } from "react-i18next";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import CategoryIcon from '@mui/icons-material/Category';
import ApiService from "../../../../services/apiServices/apiService";
import DropZone from "../../../dropzone";
import DoDisturbOnIcon from '@mui/icons-material/DoDisturbOn';





export default function Preferences() {


  const [imagePreview, setImagePreview] = useState<any>(null);

  const initialValues = {
    nameEn: '',
    nameSp: '',
    descriptionEn: '',
    descriptionSp: '',
    image: ''
  };


  const handleDropFile = (event: any) => {
    // const file = event[0];
    // if (!file) return;

    // const reader = new FileReader();
    // reader.readAsDataURL(file);

    // reader.onloadend = async () => {
    //     if (!reader.result) return;

    //     const base64String = reader.result.toString().split(",")[1];
    //     if (!base64String) return;

    //     const mimetype = file.type;
    //     const imageData = { image: base64String, mimetype };

    //     setImagePreview(reader.result.toString());
    //     setFieldValue("image", imageData);
    // };
  };
  const removeImage = () => {
    // setImagePreview(null);
    // setFieldValue("image", null);
  }

  return <Card>
    <H6 fontSize={14} px={1} m={2}>
      General Preferences
    </H6>


    <Divider />

    <Box padding={3}>
      <Grid container spacing={4}>
        <Grid size={{
          xs: 12
        }}>
          <TextField fullWidth value="" label="Global name" variant="outlined" />
        </Grid>

        <Grid size={{
          sm: 4,
          xs: 12
        }}>
          <fieldset aria-hidden="true" style={{
            padding: '8px', border: '1px solid #e5e7eb', borderRadius: '8px', height:'100%'

          }} >
            <legend style={{ color: '#0009 ', fontWeight: 400, fontSize: '1rem', lineHeight: ' 1.4375em', transform: 'scale(0.75)' }} ><span>Site logo</span></legend>
            {
              imagePreview && typeof imagePreview !== null && imagePreview !== undefined && imagePreview.trim() !== "" ?
                <FlexBox gap={2} justifyContent={'center'}>
                  <Box sx={{ width: { xs: '50%', md: '100px', lg: '150px' }, p: 0, height: { xs: 'auto', md: '100px', lg: '150px' }, position: 'relative' }}>
                    <span onClick={() => { removeImage() }} style={{ position: "absolute", top: '-10px', right: '-10px', cursor: "pointer" }}>
                      <DoDisturbOnIcon sx={{ fontSize: "20px", color: 'red' }} />
                    </span>
                    <img src={imagePreview} width={'100%'} height={'100%'} style={{ objectFit: "cover", borderRadius: 10, }} />
                  </Box>
                </FlexBox>
                :
                <DropZone
                  onDrop={(e: any) => { handleDropFile(e) }}
                  maxFiles={1}
                  minFiles={1}
                  curFile={1}
                  // curFile={values?.image ? values.image.length : 0} 
                  accept={['.png', '.gif', '.jpeg', '.jpg']}
                  // formError={errors.image}
                  placeholder={'Drop files here or click to upload.'}
                  paragraph={'Upload up to 1 files'}
                />
            }
          </fieldset>
        </Grid>
        <Grid size={{
          sm: 4,
          xs: 12
        }}>
          <fieldset aria-hidden="true" style={{
            padding: '8px', border: '1px solid #e5e7eb', borderRadius: '8px', height:'100%'

          }} >
            <legend style={{ color: '#0009 ', fontWeight: 400, fontSize: '1rem', lineHeight: ' 1.4375em', transform: 'scale(0.75)' }} ><span>The logo for darkmode</span></legend>
            {
              imagePreview && typeof imagePreview !== null && imagePreview !== undefined && imagePreview.trim() !== "" ?
                <FlexBox gap={2} justifyContent={'center'}>
                  <Box sx={{ width: { xs: '50%', md: '100px', lg: '150px' }, p: 0, height: { xs: 'auto', md: '100px', lg: '150px' }, position: 'relative' }}>
                    <span onClick={() => { removeImage() }} style={{ position: "absolute", top: '-10px', right: '-10px', cursor: "pointer" }}>
                      <DoDisturbOnIcon sx={{ fontSize: "20px", color: 'red' }} />
                    </span>
                    <img src={imagePreview} width={'100%'} height={'100%'} style={{ objectFit: "cover", borderRadius: 10, }} />
                  </Box>
                </FlexBox>
                :
                <DropZone
                  onDrop={(e: any) => { handleDropFile(e) }}
                  maxFiles={1}
                  minFiles={1}
                  curFile={1}
                  // curFile={values?.image ? values.image.length : 0} 
                  accept={['.png', '.gif', '.jpeg', '.jpg']}
                  // formError={errors.image}
                  placeholder={'Drop files here or click to upload.'}
                  paragraph={'Upload up to 1 files'}
                />
            }
          </fieldset>
        </Grid>

        

        <Grid size={{
          sm: 6,
          xs: 12
        }}>
          <FlexBetween>
            <div>
              <Paragraph fontWeight={500}>Early release</Paragraph>
              <Small color="text.secondary">Get included on new features.</Small>
            </div>

            <Switch defaultChecked />
          </FlexBetween>

          <FlexBetween mt={2}>
            <div>
              <Paragraph fontWeight={500}>See info about people who view my profile</Paragraph>
              <Small color="text.secondary">More about viewer info.</Small>
            </div>

            <Switch defaultChecked />
          </FlexBetween>
        </Grid>
      </Grid>
    </Box>


    <Stack direction="row" spacing={3} padding={3}>
      <Button variant="contained">Save Changes</Button>
      <Button variant="outlined">Cancel</Button>
    </Stack>
  </Card>;
}