import Box from '@mui/material/Box';
import Card from '@mui/material/Card';
import Grid from '@mui/material/Grid2';
import Button from '@mui/material/Button';
import Divider from '@mui/material/Divider';
import TextField from '@mui/material/TextField';
import KeyboardArrowDown from '@mui/icons-material/KeyboardArrowDown';
import * as Yup from 'yup';
import { useFormik } from 'formik'; // CUSTOM COMPONENTS

import { H6, Paragraph } from '../../../../../components/typography';
import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppSelector } from '../../../../../services/store/hooks/hooks';
import { RootState } from '../../../../../services/store/store';
import ApiService from '../../../../../services/apiServices/apiService';
import LoadingButton from '@mui/lab/LoadingButton';
import Toast from '../../../../../utils/toast';
import { FlexBox } from '../../../../flexbox';
import { TextBox } from '../../../../textbox';
import Checkbox from '@mui/material/Checkbox';
export default function InfoForm() {

  const navigate = useNavigate();
  
  const [userDetails, setUserData] = useState<any>(false);
  const [isSubmitting, setIsSubmitting] = useState<any>(false);
  const [isLoading, setIsLoading] = useState(true);
  
  const { t } = useTranslation();

  const userData: any = useAppSelector((state: RootState) => state.user);

  useEffect(() => {
    getUserData();
  }, []);

  const getUserData = async () => {
    try {
      let data = await ApiService.getUserData();
      setUserData(data.data.data.userData);
    } catch (e) {
      console.log(e);
    } finally {
      setIsLoading(false);
    }
  };

  const validationSchema = Yup.object({
    firstName: Yup.string().min(3, 'Must be greater then 3 characters').required('First Name is Required!'),
    lastName: Yup.string().required('Last Name is Required!'),
    key: Yup.string().required('key is Required!'),
    Url: Yup.string().required('Url is Required!'),
    currency: Yup.string().required('Currency is Required!'),
    language: Yup.string().required('Language is Required!')
  });

  const initialValues = {
    firstName: userDetails.firstName,
    lastName: userDetails.lastName,
    key: userDetails.key,
    Url: userDetails.Url,
    currency: userDetails.currency,
    language: userDetails.language,
  };
  
  const {
    values,
    errors,
    handleSubmit,
    handleChange,
    handleBlur,
    touched
  } = useFormik({
    initialValues,
    validationSchema,
    enableReinitialize: true,
    onSubmit: async (values: any) => {
      try {
        setIsSubmitting(true);
        let saveProfileData = await ApiService.saveProfile({id: userData.userDetails.id, firstName: values.firstName, lastName: values.lastName, currency: values.currency, language: values.language });
        Toast.showSuccessMessage("Profile Updated Successfully");
      } catch (error: any) {
        console.log('error: ', error);
        Toast.showErrorMessage(error.response.data.message);
        setIsSubmitting(false);
      }finally{
        setIsSubmitting(false);
      }
    }
  });

  return <Card>
      <H6 fontSize={14} px={1} m={2}>
      Envia Settings
      </H6>

      <Divider />

      {
        isLoading ? "Loading..." :
        <form onSubmit={handleSubmit}>
          <Box margin={3}>
            <Grid container spacing={3}>

              
              <Grid size={{ xs: 12 }}>
                  <H6 fontSize={14} >SMTP Transport</H6>
              </Grid>
              <Grid size={{
                sm: 6,
                xs: 12
              }}>
                <TextBox type={"text"} fullWidth name="host" placeholder={"Host"} onBlur={handleBlur} onChange={handleChange} value={values.host} helperText={touched.host && errors.host ? String(errors.host) : ""} error={Boolean(touched.host && errors.host)}
              
              />
              
              </Grid>

              <Grid size={{
                sm: 6,
                xs: 12
              }}>
               <TextBox type={"text"} fullWidth name="port" placeholder={"Port"} onBlur={handleBlur} onChange={handleChange} value={values.port} helperText={touched.port && errors.port ? String(errors.port) : ""} error={Boolean(touched.port && errors.port)}
             
              />
              </Grid>
              <Grid size={{
                    xs: 12
                  }}>
                    <label style={{ pl:0, display:'flex', justifyContent:'left', alignItems:'center' }} >
                      <Checkbox sx={{ p: 0, color:'primary.main','&.Mui-checked':{color:'primary.main'}, mr:0.5, }} checked={true} onChange={() => {}} />
                      <Paragraph m={0} color="Black" fontSize={14} fontWeight={400}>
                        Secure (true for port 465, false for other ports)
                      </Paragraph>
                    </label>
                  </Grid>
              <Grid size={{
                sm: 6,
                xs: 12
              }}>
                <TextBox type={"text"} fullWidth name="authuser" placeholder={"Auth user"} onBlur={handleBlur} onChange={handleChange} value={values.authuser} helperText={touched.authuser && errors.authuser ? String(errors.authuser) : ""} error={Boolean(touched.authuser && errors.authuser)}
              
              />
              
              </Grid>

              <Grid size={{
                sm: 6,
                xs: 12
              }}>
               <TextBox type={"text"} fullWidth name="authpassword" placeholder={"Auth password"} onBlur={handleBlur} onChange={handleChange} value={values.authpassword} helperText={touched.authpassword && errors.authpassword ? String(errors.authpassword) : ""} error={Boolean(touched.authpassword && errors.authpassword)}
             
              />
              </Grid>
              <Grid size={{
                sm: 6,
                xs: 12
              }}>

              <Paragraph m={0} color="Black" fontSize={14} fontWeight={400}>
                Set up SMTP here
                </Paragraph>
                <Button type='button' variant='text' color='info' sx={{p:0, mt:1}} disableTouchRipple>
                Once saved, click here to send a test email.
                </Button>
              </Grid>
              

             
              <Grid size={12}>
                <FlexBox gap={2}>
                
                <LoadingButton loading={isSubmitting} type="submit" variant="contained"  sx={{minWidth:'120px' }}>
                  Save
                </LoadingButton>
                </FlexBox>

              </Grid>
            </Grid>
          </Box>
        </form>
      }
    </Card>;
}