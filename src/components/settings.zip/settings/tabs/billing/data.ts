export const BILLING_HISTORY = [{
  id: 1,
  amount: 890,
  invoice: 'PDF',
  date: 'Nov 12, 2021',
  description: 'Invoice for Octavia'
}, {
  id: 2,
  amount: 420,
  invoice: 'DOC',
  date: 'Nov 10, 2021',
  description: 'Invoice for Uko'
}, {
  id: 3,
  amount: 590,
  invoice: 'PDF',
  date: 'Nov 24, 2021',
  description: 'Invoice for Stocky'
}, {
  id: 4,
  amount: 750,
  invoice: 'DOC',
  date: 'Nov 19, 2021',
  description: 'Invoice for Aatrox'
}, {
  id: 5,
  amount: 890,
  invoice: 'PDF',
  date: 'Nov 12, 2021',
  description: 'Invoice for Octavia'
}];